# Sami Gichki Consulting — Website

Version 1.0 | 2026
Brand Guidelines v2.0

---

## File structure

Copy this entire folder into VS Code exactly as shown:

```
sgc-website/
│
├── index.html                  ← Single HTML file (all 6 pages inside)
│
├── css/
│   ├── global.css              ← Design tokens, layout, all shared components
│   ├── nav.css                 ← Navigation bar + footer styles
│   └── hero.css                ← Home page hero section
│
├── js/
│   └── main.js                 ← Navigation, FAQ accordion, form, mobile menu
│
└── assets/
    ├── fonts/                  ← Glacial Indifference font files (see below)
    │   ├── GlacialIndifference-Regular.woff2
    │   ├── GlacialIndifference-Regular.woff
    │   ├── GlacialIndifference-Bold.woff2
    │   └── GlacialIndifference-Bold.woff
    │
    ├── icons/                  ← Favicon files (see below)
    │   ├── favicon.ico
    │   ├── favicon-32x32.png
    │   └── apple-touch-icon.png
    │
    └── images/                 ← (optional) photography assets
        └── og-image.jpg        ← 1200×630px Open Graph image for social sharing
```

---

## Pages (all inside index.html)

The site uses a single-page application pattern. All six pages live in
index.html and are shown/hidden by JavaScript. No server required — open
index.html directly in a browser to preview.

| Page ID       | Triggered by nav link | Content                                              |
|---------------|-----------------------|------------------------------------------------------|
| page-home     | Home                  | Hero, problem, domains, pilot banner, testimonials   |
| page-about    | About                 | Founder bio, credentials, values                     |
| page-services | Services              | CGRD overview, 5-phase process, outputs, FAQ         |
| page-sectors  | Sectors               | NHS, Charities, Housing, Social Enterprise, LA       |
| page-insights | Insights              | UK LLC preprint, thought leadership, coming soon     |
| page-contact  | Book a call           | Contact form, direct contact info, next steps        |

---

## Fonts

**Barlow** is loaded from Google Fonts via the `<link>` tag in `<head>` —
no download needed. Requires internet connection.

**Glacial Indifference** must be downloaded and placed in `assets/fonts/`.
Download from: https://www.fontsquirrel.com/fonts/glacial-indifference
or: https://befonts.com/glacial-indifference-font.html

Files needed:
- GlacialIndifference-Regular.woff2
- GlacialIndifference-Regular.woff
- GlacialIndifference-Bold.woff2
- GlacialIndifference-Bold.woff

The @font-face declarations are already written in css/global.css.
Just drop the files in assets/fonts/ and they will load automatically.

If fonts are unavailable, the fallback stack is:
- Display: Century Gothic → Futura → sans-serif
- Body: Gill Sans → Nunito → sans-serif

---

## Colours (brand tokens)

All colours are defined as CSS custom properties in css/global.css:

| Variable       | Hex       | Role                                      |
|----------------|-----------|-------------------------------------------|
| --navy         | #0D3B66   | Primary brand colour, nav, headings       |
| --coral        | #F95738   | Accent, CTAs, interactive elements        |
| --mint         | #A8E6CF   | Secondary accent, dividers, highlights    |
| --white        | #ffffff   | Background, negative space                |
| --light-grey   | #F4F6F8   | Alternate section backgrounds             |
| --dark-grey    | #4A5568   | Body text                                 |
| --mid-grey     | #e2e8f0   | Borders, dividers                         |

---

## Typography scale

| Element          | Font                  | Weight | Approx size |
|------------------|-----------------------|--------|-------------|
| Hero title       | Glacial Indifference  | 700    | 3rem        |
| Section titles   | Glacial Indifference  | 700    | 2rem        |
| Card titles      | Glacial Indifference  | 700    | 1.05rem     |
| Body copy        | Barlow                | 400    | 1rem        |
| Eyebrow labels   | Barlow                | 700    | 0.75rem     |
| Button text      | Barlow                | 700    | 0.9rem      |
| Captions         | Barlow                | 300    | 0.82rem     |

---

## Navigation system

Navigation is handled by main.js. Every link/button that changes the page uses:

```html
<a href="#" data-page="services">Services</a>
<!-- or -->
<button data-page="contact">Book a call</button>
```

The JS picks up all `[data-page]` attributes on DOMContentLoaded.
No manual event listeners needed in the HTML.

To add a new page:

1. Add a new `<div id="page-newpage" class="js-page">` block in index.html
2. Add a nav link: `<a href="#" data-page="newpage">New Page</a>`
3. Add a footer link in the same way
4. Add a nav item to the mobile drawer

---

## Adding the contact form backend

The form currently shows a toast confirmation on submit (no data is sent).
To wire it to a real backend, replace the submit handler in main.js:

**Option A — Formspree (no backend needed, free tier available):**
```html
<form class="contact-form" action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
```
Remove the `js-contact-form` class and the JS handler. Formspree handles submission.

**Option B — Netlify Forms (if deploying to Netlify):**
```html
<form class="contact-form" name="contact" method="POST" data-netlify="true">
  <input type="hidden" name="form-name" value="contact">
```

**Option C — EmailJS (sends email from the browser, no server):**
Install EmailJS SDK and call `emailjs.sendForm()` in the submit handler in main.js.

---

## Deployment options

**Local preview:** Open index.html directly in any browser. Works offline
(except Barlow font and Google Fonts, which need internet).

**GitHub Pages (free):**
1. Push the sgc-website folder to a GitHub repo
2. Go to Settings → Pages → Source: main branch / root
3. Site is live at https://username.github.io/repo-name

**Netlify (free, recommended — supports form handling):**
1. Drag and drop the sgc-website folder to netlify.com/drop
2. Add a custom domain (samigichki.co.uk) in Site settings

**Custom domain:**
Point your domain's DNS A record to the host's IP.
For Netlify: follow https://docs.netlify.com/domains-https/custom-domains/

---

## Adding a favicon

Generate a favicon set from your logo at: https://realfavicongenerator.net
Place the output files in assets/icons/ and add these to the `<head>` in index.html:

```html
<link rel="icon" type="image/x-icon" href="assets/icons/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="assets/icons/favicon-32x32.png">
<link rel="apple-touch-icon" href="assets/icons/apple-touch-icon.png">
```

---

## Adding Open Graph / social preview

Add these to the `<head>` for LinkedIn and Twitter card previews:

```html
<meta property="og:title" content="Sami Gichki Consulting | Culture & Governance Risk">
<meta property="og:description" content="Independent culture and governance risk diagnostics for the NHS, charities, housing associations and public bodies.">
<meta property="og:image" content="https://samigichki.co.uk/assets/images/og-image.jpg">
<meta property="og:url" content="https://samigichki.co.uk">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
```

og-image.jpg should be 1200×630px, navy background, white logo and tagline.

---

## SEO

Each page currently shares one `<title>` and `<meta name="description">`.
For better per-page SEO (and if converting to a multi-page site later),
update the title and meta description dynamically in the showPage() function in main.js:

```javascript
var pageMeta = {
  home:     { title: 'Sami Gichki Consulting | Culture & Governance Risk', desc: '...' },
  about:    { title: 'About | Sami Gichki Consulting', desc: '...' },
  services: { title: 'The CGRD | Sami Gichki Consulting', desc: '...' },
  // etc.
};

function showPage(pageId) {
  // ... existing code ...
  if (pageMeta[pageId]) {
    document.title = pageMeta[pageId].title;
    document.querySelector('meta[name="description"]').content = pageMeta[pageId].desc;
  }
}
```

---

## Browser support

Works in all modern browsers (Chrome, Firefox, Safari, Edge).
No build step. No dependencies. No npm. Just open index.html.

---

## Brand contacts

Brand assets (logo SVG/PNG/EPS, Canva templates, PowerPoint master):
hello@samigichki.com

Website: samigichki.co.uk
Email: hello@samigichki.com

© 2026 Sami Gichki Consulting. Confidential.
